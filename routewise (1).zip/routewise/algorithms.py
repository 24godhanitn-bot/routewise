"""Core DSA algorithms: Dijkstra (min-heap), A*, BFS, Held-Karp DP, Kruskal + Union-Find."""
import heapq
from collections import deque
from graph import haversine, MAX_SPEED

INF = float("inf")


def _build_path(prev, src, dst):
    path, cur = [], dst
    while cur is not None:
        path.append(cur)
        cur = prev.get(cur)
    path.reverse()
    return path if path and path[0] == src else []


def _dijkstra_all(g, src, mode, target=None):
    dist, prev = {src: 0}, {src: None}
    heap = [(0, src)]                       # priority queue (min-heap)
    done = set()
    while heap:
        d, u = heapq.heappop(heap)
        if u in done:
            continue
        done.add(u)
        if u == target:
            break
        for v, w in g.neighbors(u, mode):
            nd = d + w
            if nd < dist.get(v, INF):
                dist[v], prev[v] = nd, u
                heapq.heappush(heap, (nd, v))
    return dist, prev, len(done)


def dijkstra(g, src, dst, mode="distance"):
    """Returns (cost, path, nodes_explored)."""
    dist, prev, explored = _dijkstra_all(g, src, mode, dst)
    if dst not in dist:
        return INF, [], explored
    return dist[dst], _build_path(prev, src, dst), explored


def a_star(g, src, dst, mode="distance"):
    """A* with a straight-line (haversine) heuristic. Returns (cost, path, explored)."""
    scale = 1 if mode == "distance" else 60 / MAX_SPEED   # keeps heuristic admissible
    h = lambda n: haversine(g.coords[n], g.coords[dst]) * scale
    best, prev = {src: 0}, {src: None}
    heap = [(h(src), 0, src)]
    done = set()
    while heap:
        _, d, u = heapq.heappop(heap)
        if u in done:
            continue
        done.add(u)
        if u == dst:
            return d, _build_path(prev, src, dst), len(done)
        for v, w in g.neighbors(u, mode):
            nd = d + w
            if nd < best.get(v, INF):
                best[v], prev[v] = nd, u
                heapq.heappush(heap, (nd + h(v), nd, v))
    return INF, [], len(done)


def fewest_stops(g, src, dst):
    """BFS: path with the minimum number of road segments."""
    prev, q = {src: None}, deque([src])
    while q:
        u = q.popleft()
        if u == dst:
            return len(_build_path(prev, src, dst)) - 1, _build_path(prev, src, dst)
        for v, _ in g.neighbors(u, "distance"):
            if v not in prev:
                prev[v] = u
                q.append(v)
    return INF, []


def optimize_stops(g, start, stops, mode="distance", round_trip=False):
    """Multi-stop delivery route (TSP) using Held-Karp bitmask DP. Max 10 stops.
    Returns (total_cost, visiting_order, full_city_by_city_path)."""
    stops = [s for s in dict.fromkeys(stops) if s != start]
    n = len(stops)
    if n == 0:
        return 0, [start], [start]
    if n > 10:
        raise ValueError("Maximum 10 stops supported")
    nodes = [start] + stops
    d = [[0] * (n + 1) for _ in range(n + 1)]
    paths = {}
    for i, a in enumerate(nodes):
        dist, prev, _ = _dijkstra_all(g, a, mode)
        for j, b in enumerate(nodes):
            if b not in dist:
                raise ValueError(f"No route between {a} and {b}")
            d[i][j] = dist[b]
            paths[(i, j)] = _build_path(prev, a, b)

    full = (1 << n) - 1
    dp = {(1 << j, j): (d[0][j + 1], -1) for j in range(n)}   # (mask, last) -> (cost, parent)
    for mask in range(1, full + 1):
        for j in range(n):
            if (mask, j) not in dp:
                continue
            cost = dp[(mask, j)][0]
            for k in range(n):
                if mask >> k & 1:
                    continue
                nm, nc = mask | 1 << k, cost + d[j + 1][k + 1]
                if (nm, k) not in dp or nc < dp[(nm, k)][0]:
                    dp[(nm, k)] = (nc, j)

    best = min((dp[(full, j)][0] + (d[j + 1][0] if round_trip else 0), j) for j in range(n))
    order, mask, j = [], full, best[1]
    while j != -1:
        order.append(j)
        pj = dp[(mask, j)][1]
        mask ^= 1 << j
        j = pj
    order.reverse()
    seq = [0] + [x + 1 for x in order] + ([0] if round_trip else [])
    route = [nodes[0]]
    for a, b in zip(seq, seq[1:]):
        route += paths[(a, b)][1:]
    return best[0], [nodes[i] for i in seq], route


class UnionFind:
    def __init__(self, items):
        self.parent = {x: x for x in items}
        self.rank = {x: 0 for x in items}

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]   # path compression
            x = self.parent[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False
        if self.rank[ra] < self.rank[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        if self.rank[ra] == self.rank[rb]:
            self.rank[ra] += 1
        return True


def minimum_spanning_network(g, mode="distance"):
    """Kruskal: cheapest set of roads that keeps every city connected."""
    edges = sorted((g.weight(u, v, mode), u, v) for u, v, _, _ in g.roads())
    uf, chosen, total = UnionFind(g.coords), [], 0
    for w, u, v in edges:
        if uf.union(u, v):
            chosen.append((u, v, w))
            total += w
    return total, chosen
