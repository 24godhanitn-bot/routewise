"""RouteWise - Flask web app. Run: python app.py"""
from flask import Flask, jsonify, render_template, request
from data import load_sample_graph
from algorithms import dijkstra, a_star, optimize_stops, minimum_spanning_network, fewest_stops
from utils import fmt

app = Flask(__name__)
g = load_sample_graph()


def blocked_list():
    return [sorted(x) for x in g.blocked]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/graph")
def api_graph():
    return jsonify(cities=g.coords,
                   roads=[dict(u=u, v=v, km=km, road=r) for u, v, km, r in g.roads()],
                   blocked=blocked_list())


@app.route("/api/route")
def api_route():
    s, d = request.args.get("src"), request.args.get("dst")
    mode, algo = request.args.get("mode", "distance"), request.args.get("algo", "dijkstra")
    if s not in g.coords or d not in g.coords:
        return jsonify(error="Unknown city"), 400
    if algo == "bfs":
        hops, path = fewest_stops(g, s, d)
        cost_txt = f"{hops} road segments"
        explored = None
    else:
        cost, path, explored = (a_star if algo == "astar" else dijkstra)(g, s, d, mode)
        cost_txt = fmt(cost, mode)
    if not path:
        return jsonify(error="No route available (roads may be blocked)"), 404
    return jsonify(path=path, cost=cost_txt, explored=explored)


@app.route("/api/multistop", methods=["POST"])
def api_multistop():
    j = request.get_json()
    mode = j.get("mode", "distance")
    try:
        cost, order, route = optimize_stops(g, j["start"], j["stops"], mode, j.get("round_trip", False))
    except (ValueError, KeyError) as e:
        return jsonify(error=str(e)), 400
    return jsonify(order=order, path=route, cost=fmt(cost, mode))


@app.route("/api/block", methods=["POST"])
def api_block():
    j = request.get_json()
    u, v = j["u"], j["v"]
    if j.get("blocked"):
        if not g.block(u, v):
            return jsonify(error="No direct road there"), 400
    else:
        g.unblock(u, v)
    return jsonify(blocked=blocked_list())


@app.route("/api/mst")
def api_mst():
    mode = request.args.get("mode", "distance")
    total, edges = minimum_spanning_network(g, mode)
    return jsonify(total=fmt(total, mode), edges=[[u, v] for u, v, _ in edges])


if __name__ == "__main__":
    app.run(debug=True)
