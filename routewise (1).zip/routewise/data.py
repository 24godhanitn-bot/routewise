from graph import Graph

CITIES = {
    "Nagpur": (21.1458, 79.0882), "Wardha": (20.7453, 78.6022),
    "Amravati": (20.9320, 77.7523), "Akola": (20.7096, 77.0082),
    "Jabalpur": (23.1815, 79.9864), "Raipur": (21.2514, 81.6296),
    "Hyderabad": (17.3850, 78.4867), "Pune": (18.5204, 73.8567),
    "Mumbai": (19.0760, 72.8777), "Nashik": (19.9975, 73.7898),
    "Aurangabad": (19.8762, 75.3433), "Bhopal": (23.2599, 77.4126),
    "Indore": (22.7196, 75.8577), "Chandrapur": (19.9615, 79.2961),
}

ROADS = [
    ("Nagpur", "Wardha", "NH"), ("Nagpur", "Amravati", "NH"),
    ("Amravati", "Akola", "NH"), ("Nagpur", "Jabalpur", "NH"),
    ("Nagpur", "Raipur", "NH"), ("Nagpur", "Hyderabad", "NH"),
    ("Nagpur", "Chandrapur", "SH"), ("Wardha", "Chandrapur", "SH"),
    ("Akola", "Aurangabad", "NH"), ("Aurangabad", "Pune", "NH"),
    ("Pune", "Mumbai", "NH"), ("Aurangabad", "Nashik", "SH"),
    ("Nashik", "Mumbai", "NH"), ("Nashik", "Pune", "SH"),
    ("Jabalpur", "Bhopal", "NH"), ("Bhopal", "Indore", "NH"),
    ("Indore", "Nashik", "SH"), ("Hyderabad", "Pune", "NH"),
]


def load_sample_graph():
    g = Graph()
    for name, (lat, lon) in CITIES.items():
        g.add_city(name, lat, lon)
    for u, v, road in ROADS:
        g.add_road(u, v, road)
    return g
