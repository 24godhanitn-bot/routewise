"""Graph data structure (adjacency list) for RouteWise."""
import math
from collections import defaultdict

SPEEDS = {"NH": 70, "SH": 50}   # km/h by road type (National / State Highway)
MAX_SPEED = max(SPEEDS.values())


def haversine(a, b):
    """Straight-line distance in km between two (lat, lon) points."""
    r = 6371
    la1, lo1, la2, lo2 = map(math.radians, (*a, *b))
    h = math.sin((la2 - la1) / 2) ** 2 + \
        math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


class Graph:
    def __init__(self):
        self.coords = {}                  # city -> (lat, lon)
        self.adj = defaultdict(dict)      # city -> {neighbor: (km, road_type)}
        self.blocked = set()              # set of frozenset({u, v})

    def add_city(self, name, lat, lon):
        self.coords[name] = (lat, lon)

    def add_road(self, u, v, road="NH", km=None):
        if km is None:   # road is always longer than the straight line
            km = round(haversine(self.coords[u], self.coords[v]) * 1.3)
        self.adj[u][v] = (km, road)
        self.adj[v][u] = (km, road)

    def weight(self, u, v, mode):
        km, road = self.adj[u][v]
        return km if mode == "distance" else km / SPEEDS[road] * 60  # minutes

    def neighbors(self, u, mode):
        for v in self.adj[u]:
            if frozenset((u, v)) not in self.blocked:
                yield v, self.weight(u, v, mode)

    def block(self, u, v):
        if v in self.adj[u]:
            self.blocked.add(frozenset((u, v)))
            return True
        return False

    def unblock(self, u, v):
        self.blocked.discard(frozenset((u, v)))

    def roads(self):
        seen = set()
        for u in self.adj:
            for v, (km, road) in self.adj[u].items():
                key = frozenset((u, v))
                if key not in seen:
                    seen.add(key)
                    yield u, v, km, road
