"""RouteWise - command line interface."""
from data import load_sample_graph
from algorithms import dijkstra, a_star, fewest_stops, optimize_stops, minimum_spanning_network
from utils import fmt

g = load_sample_graph()


def pick_city(prompt):
    names = sorted(g.coords)
    while True:
        c = input(prompt).strip().title()
        if c in g.coords:
            return c
        print("  Unknown city. Available:", ", ".join(names))


def pick_mode():
    return "time" if input("Optimise for (d)istance or (t)ime? [d/t]: ").lower().startswith("t") else "distance"


def shortest():
    s, d, mode = pick_city("From: "), pick_city("To: "), pick_mode()
    for name, fn in (("Dijkstra", dijkstra), ("A*", a_star)):
        cost, path, explored = fn(g, s, d, mode)
        if not path:
            print("  No route available."); return
        print(f"  {name:9}: {' -> '.join(path)} | {fmt(cost, mode)} | explored {explored} cities")
    hops, p = fewest_stops(g, s, d)
    print(f"  BFS (fewest roads): {' -> '.join(p)} | {hops} road segments")


def multistop():
    start = pick_city("Start city: ")
    stops = [x.strip().title() for x in input("Stops (comma separated): ").split(",") if x.strip()]
    bad = [x for x in stops if x not in g.coords]
    if bad:
        print("  Unknown:", bad); return
    mode = pick_mode()
    rt = input("Return to start? [y/n]: ").lower().startswith("y")
    try:
        cost, order, route = optimize_stops(g, start, stops, mode, rt)
    except ValueError as e:
        print(" ", e); return
    print("  Best visiting order:", " -> ".join(order))
    print("  Full route:", " -> ".join(route))
    print("  Total:", fmt(cost, mode))


def road_closure():
    u, v = pick_city("Road from: "), pick_city("Road to: ")
    if frozenset((u, v)) in g.blocked:
        g.unblock(u, v); print("  Road re-opened.")
    elif g.block(u, v):
        print("  Road blocked. New routes will avoid it.")
    else:
        print("  No direct road between those cities.")


def mst():
    mode = pick_mode()
    total, edges = minimum_spanning_network(g, mode)
    for u, v, w in edges:
        print(f"  {u} - {v}: {fmt(w, mode)}")
    print("  Total network:", fmt(total, mode))


MENU = {"1": ("Shortest route (Dijkstra / A* / BFS)", shortest),
        "2": ("Multi-stop optimiser (Held-Karp DP)", multistop),
        "3": ("Block / unblock a road", road_closure),
        "4": ("Minimum road network (Kruskal)", mst)}

if __name__ == "__main__":
    print("=== RouteWise ===")
    while True:
        print()
        for k, (label, _) in MENU.items():
            print(f" {k}. {label}")
        print(" 0. Exit")
        c = input("Choice: ").strip()
        if c == "0":
            break
        MENU.get(c, (None, lambda: print("  Invalid choice")))[1]()
