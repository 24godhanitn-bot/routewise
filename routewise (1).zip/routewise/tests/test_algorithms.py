import sys, os, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from data import load_sample_graph
from algorithms import dijkstra, a_star, fewest_stops, optimize_stops, minimum_spanning_network, INF


class Tests(unittest.TestCase):
    def setUp(self):
        self.g = load_sample_graph()

    def test_astar_matches_dijkstra(self):
        for mode in ("distance", "time"):
            for s, d in [("Nagpur", "Mumbai"), ("Raipur", "Indore"), ("Akola", "Hyderabad")]:
                self.assertAlmostEqual(dijkstra(self.g, s, d, mode)[0], a_star(self.g, s, d, mode)[0])

    def test_blocked_road_changes_route(self):
        before = dijkstra(self.g, "Nagpur", "Amravati")[1]
        self.g.block("Nagpur", "Amravati")
        after = dijkstra(self.g, "Nagpur", "Amravati")[1]
        self.assertNotEqual(before, after)

    def test_no_route(self):
        for v in list(self.g.adj["Mumbai"]):
            self.g.block("Mumbai", v)
        self.assertEqual(dijkstra(self.g, "Nagpur", "Mumbai")[0], INF)

    def test_bfs(self):
        hops, path = fewest_stops(self.g, "Nagpur", "Amravati")
        self.assertEqual(hops, 1)

    def test_multistop_not_worse_than_given_order(self):
        stops = ["Mumbai", "Raipur", "Pune"]
        cost, order, route = optimize_stops(self.g, "Nagpur", stops)
        naive, cur = 0, "Nagpur"
        for s in stops:
            naive += dijkstra(self.g, cur, s)[0]
            cur = s
        self.assertLessEqual(cost, naive + 1e-9)
        self.assertEqual(set(order), set(stops) | {"Nagpur"})

    def test_mst_has_n_minus_1_edges(self):
        _, edges = minimum_spanning_network(self.g)
        self.assertEqual(len(edges), len(self.g.coords) - 1)


if __name__ == "__main__":
    unittest.main()
