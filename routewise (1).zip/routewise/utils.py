def fmt(cost, mode):
    if mode == "distance":
        return f"{cost:.0f} km"
    m = round(cost)
    return f"{m // 60}h {m % 60}m"
